<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check CSRF token
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("Invalid CSRF token");
    }

    // Verify reCAPTCHA
    $recaptcha_secret = "your_secret_key";
    $response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$recaptcha_secret&response=".$_POST['g-recaptcha-response']);
    $responseKeys = json_decode($response, true);

    if (intval($responseKeys["success"]) !== 1) {
        die("Please complete the CAPTCHA");
    }

    // Validate and sanitize input
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);

    if (empty($name) || empty($email) || empty($message)) {
        die("All fields are required!");
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email address!");
    }

    // Save to database (example using PDO)
    try {
        $pdo = new PDO('mysql:host=your_host;dbname=your_db', 'username', 'password');
        $stmt = $pdo->prepare('INSERT INTO contacts (name, email, message) VALUES (:name, :email, :message)');
        $stmt->execute(['name' => $name, 'email' => $email, 'message' => $message]);
    } catch (PDOException $e) {
        die("Database error: " . $e->getMessage());
    }

    echo "Form submitted successfully!";
}

// Generate a new CSRF token
$csrf_token = bin2hex(random_bytes(32));
$_SESSION['csrf_token'] = $csrf_token;
?>